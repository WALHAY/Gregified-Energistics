package gregtech.common.blocks;

import gregtech.api.block.IStateHarvestLevel;
import gregtech.api.block.IStateSoundType;
import gregtech.api.block.VariantBlock;
import gregtech.api.items.toolitem.ToolClasses;

import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.EntityLiving;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class BlockSteamCasing extends VariantBlock<BlockSteamCasing.SteamCasingType> {

    public BlockSteamCasing() {
        super(Material.IRON);
        setTranslationKey("steam_casing");
        setHardness(4.0f);
        setResistance(8.0f);
        setSoundType(SoundType.METAL);
        setDefaultState(getState(SteamCasingType.BRONZE_HULL));
    }

    @Override
    public boolean canCreatureSpawn(@NotNull IBlockState state, @NotNull IBlockAccess world, @NotNull BlockPos pos,
                                    @NotNull EntityLiving.SpawnPlacementType type) {
        return false;
    }

    @Override
    public void addInformation(@NotNull ItemStack stack, @Nullable World player, @NotNull List<String> tooltip,
                               @NotNull ITooltipFlag advanced) {
        int ordinal = getState(stack).ordinal();
        if (ordinal < 2) {
            tooltip.add(I18n.format("tile.steam_casing.bronze.tooltip"));
        } else if (ordinal < 4) {
            tooltip.add(I18n.format("tile.steam_casing.steel.tooltip"));
        } else {
            super.addInformation(stack, player, tooltip, advanced);
        }
    }

    public enum SteamCasingType implements IStringSerializable, IStateHarvestLevel, IStateSoundType {

        BRONZE_HULL("bronze_hull", 1),
        BRONZE_BRICKS_HULL("bronze_bricks_hull", 1),
        STEEL_HULL("steel_hull", 2),
        STEEL_BRICKS_HULL("steel_bricks_hull", 2),
        PUMP_DECK("pump_deck", 1, SoundType.WOOD),
        WOOD_WALL("wood_wall", 0, SoundType.WOOD);

        private final String name;
        private final int harvestLevel;
        private final SoundType soundType;

        SteamCasingType(String name, int harvestLevel, SoundType soundType) {
            this.name = name;
            this.harvestLevel = harvestLevel;
            this.soundType = soundType;
        }

        SteamCasingType(String name, int harvestLevel) {
            this(name, harvestLevel, SoundType.METAL);
        }

        @Override
        @NotNull
        public String getName() {
            return name;
        }

        @Override
        public int getHarvestLevel(IBlockState state) {
            return harvestLevel;
        }

        @Override
        public String getHarvestTool(IBlockState state) {
            return ToolClasses.WRENCH;
        }

        @NotNull
        @Override
        public SoundType getSoundType(@NotNull IBlockState state) {
            return soundType;
        }
    }
}
